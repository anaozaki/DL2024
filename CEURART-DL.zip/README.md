CEURART-DL v3 based on CEURART v0.4.7
2022-06-14

# LaTeX user template and guide

To compile user guide:

1. `pdflatex sample-1col`
2. `bibtex sample-1col`
3. `pdflatex sample-1col`
4. `pdflatex sample-1col`

and

1. `pdflatex sample-2col`
2. `bibtex sample-2col`
3. `pdflatex sample-2col`
4. `pdflatex sample-2col`

or

use the makefile:

`make`

Note: Complex control sequences (such as \mathcal{}) in the \title{} cause problems, however authors wishing to used them may use a patched version of the .cls by Franesco Kriegel, available here:
https://github.com/francesco-kriegel/ceurart/blob/master/tex/latex/ceurart/ceurart.cls

Or the following workaround can be used: First format your title without control sequences. Compile the paper by calling `make`. Then add control sequences and compile the paper once calling `lualatex paper.tex` or `pdflatex paper.tex` to obtain the final PDF.

